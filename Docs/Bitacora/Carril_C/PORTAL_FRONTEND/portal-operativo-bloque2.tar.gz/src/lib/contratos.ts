// Tipos de las respuestas (`data`) de portal-api, espejando CONTRATO_FRONTEND_PORTAL_v1.md.
// Crece por bloque a medida que entran las pantallas reales. NO reabre el contrato.

/** A03/A04 (D-FE-03): calendarios HTML temporal. data: { formato:"html", html }. */
export interface CalendarioHtmlData {
  formato: string;
  html: string;
}
