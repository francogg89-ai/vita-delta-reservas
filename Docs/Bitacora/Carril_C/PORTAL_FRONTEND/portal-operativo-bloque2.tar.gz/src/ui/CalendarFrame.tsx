import { useCallback, useEffect, useRef, useState } from 'react';

const ALTO_MIN = 240; // px: mientras mide / si no pudiera leer el documento

/**
 * Render del HTML temporal de los calendarios A03/A04 (D-FE-03 / D-FE-14, opcion A).
 *
 *  - iframe `srcDoc` con `sandbox="allow-same-origin"` y SIN `allow-scripts`: aisla los
 *    estilos del HTML del backend (y los de la app), y NO ejecuta los scripts del HTML.
 *  - El HTML es first-party (nuestro backend) y trae el texto dinamico escapado, asi que
 *    same-origin -para poder MEDIR el alto- es aceptable; los scripts siguen apagados.
 *    (Sin `allow-same-origin`, el srcDoc tendria origin opaco y contentDocument seria
 *    inaccesible; por eso esa flag habilita el autosize.)
 *  - Autosize: en `onLoad` se lee `contentDocument` y se ajusta el alto. Se re-mide en
 *    `resize` de ventana (al cambiar el ancho del iframe el contenido reflowea -> cambia
 *    el alto). Al cambiar el `html` se vuelve al alto minimo hasta que onLoad re-mida.
 *  - NO se reinterpreta el HTML como datos (D-FE-03): se renderiza tal cual.
 */
export function CalendarFrame({ html, title }: { html: string; title: string }) {
  const ref = useRef<HTMLIFrameElement>(null);
  const [alto, setAlto] = useState(ALTO_MIN);

  const medir = useCallback(() => {
    const doc = ref.current?.contentDocument;
    if (!doc) return;
    const h = Math.max(doc.documentElement?.scrollHeight ?? 0, doc.body?.scrollHeight ?? 0);
    if (h > 0) setAlto(h);
  }, []);

  // El contenido reflowea cuando cambia el ancho de ventana -> re-medir.
  useEffect(() => {
    window.addEventListener('resize', medir);
    return () => window.removeEventListener('resize', medir);
  }, [medir]);

  // HTML nuevo -> alto minimo hasta que onLoad mida el nuevo documento.
  useEffect(() => {
    setAlto(ALTO_MIN);
  }, [html]);

  return (
    <div className="overflow-hidden rounded-2xl border border-sand bg-white">
      <iframe
        ref={ref}
        title={title}
        srcDoc={html}
        sandbox="allow-same-origin"
        onLoad={medir}
        className="block w-full"
        style={{ height: alto, border: 0 }}
      />
    </div>
  );
}
