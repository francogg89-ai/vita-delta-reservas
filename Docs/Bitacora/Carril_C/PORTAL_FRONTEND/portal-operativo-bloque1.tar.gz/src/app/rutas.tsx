import { Navigate, Route, Routes } from 'react-router-dom';
import { ACTION_REGISTRY } from '../lib/actionRegistry';
import { RutaProtegida } from './RutaProtegida';
import { PlaceholderView } from './PlaceholderView';
import { Home } from './Home';

/**
 * Tabla de rutas del portal (D-FE-12). Se deriva de ACTION_REGISTRY (presentacion-only,
 * D-FE-09): cada `ruta` del registry se cablea a una pantalla, envuelta en el guard de
 * rol (RutaProtegida). El registry NO se toca.
 *
 * Bloque 1: TODAS las acciones renderizan PlaceholderView (lecturas -> "sub-slice 1",
 * escrituras -> "sub-slice 2"). En los bloques siguientes se reemplazan las rutas de
 * lectura por las pantallas reales, una por bloque (Bloque 2 = calendarios A03/A04).
 *
 * `path` se deriva quitando el slash inicial de `ruta` (rutas planas bajo la raiz);
 * los NavLink del menu usan la `ruta` absoluta. Ruta desconocida -> redirect a `/`.
 */
export function AppRoutes() {
  return (
    <Routes>
      <Route index element={<Home />} />
      {Object.values(ACTION_REGISTRY).map((meta) => (
        <Route
          key={meta.action}
          path={meta.ruta.replace(/^\//, '')}
          element={
            <RutaProtegida action={meta.action}>
              <PlaceholderView meta={meta} />
            </RutaProtegida>
          }
        />
      ))}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
